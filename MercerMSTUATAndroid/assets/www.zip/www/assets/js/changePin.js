


function changePin(newPin)
{
    console.log(cordova);
}

